const express=require("express")
const app=express()


app.get("/",(req,res)=>{
console.log("app started")
res.sendFile("./cssGame.html",{root:__dirname})
})
app.get("/rickrol.mp4",(req,res)=>{
res.sendFile("./rickrol.mp4",{root:__dirname})
})


app.listen(8080,()=>{

console.log("listening")
})
